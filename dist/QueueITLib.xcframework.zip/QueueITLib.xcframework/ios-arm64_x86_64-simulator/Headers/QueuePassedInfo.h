#import <Foundation/Foundation.h>

@interface QueuePassedInfo : NSObject

@property (nonatomic, strong) NSString* _Nullable queueitToken;

-(instancetype _Nonnull )initWithQueueitToken:(NSString* _Nullable) queueitToken;

@end
