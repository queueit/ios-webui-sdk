#ifndef QueueConsts_h
#define QueueConsts_h

#define QueueCloseUrl @"queueit://close"
#define QueueRestartSessionUrl @"queueit://restartSession"
#define SDKVersion @"iOS-3.1.14";

#endif
